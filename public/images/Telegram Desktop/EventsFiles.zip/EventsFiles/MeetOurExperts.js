const meetourexpert=[
    {
        id:1,
        image:'/images/Nanda-Kumar-Sreedharan-1.jpg',
        name:'NANDA KUMAR SREEDHARAN',
        designation:'Senior Vice President, Sales – Americas',
        content:'Nanda is responsible for new business development and engagement management across the American market. He has over two decades of experience working across industries and expertise in selling pricing, billing and revenue management software.'
    },
    {
        id:2,
        image:'/images/img-2-1 copy.jpg',
        name:'NIKHIL MANCHANDA',
        designation:'Senior Consultant',
        content:'Nikhil is based in Toronto, Canada and is responsible for Presales and Solution Consulting for SunTec’s business across the Americas. As a solution expert he loves to provide solutions to solve client problems and believes that a complex problem can be solved using micro/ bite sized solutions. Looking forward to connecting with like-minded people and organizations.'
    },
    {
        id:3,
        image:'/images/img-1.jpg',
        name:'AMRIT SABOO',
        designation:'Sales Director',
        content:'Amrit has been instrumental in helping banking and financial institutions to meet their business objectives through innovative technology solutions. He has been with SunTec for three years and partnered with multiple financial institutions in North America to effectively leverage SunTec’s Xelerate capabilities. Money 20/20 is all about innovation and I am looking forward to meeting and networking.'
    },
    {
        id:4,
        image:'/images/img-3-1.jpg',
        name:'SAM DAVIDOWITZ',
        designation:'Director of Sales and Engagement Management',
        content:'Sam is based in Pittsburgh, responsible for SunTec’s new business development and engagement management across the North American market. He has experience helping organizations reimagine banking in a customer driven world with personalization, ecosystem monetization and core modernization.'
    },
];
export default meetourexpert