const meetourteam=[
    {
        id:1,
        image:'/images/Amit-new-300x300.png',
        name:'AMIT DUA',
        designation:'President',
        content:'Amit Dua is President, SunTec Business Solutions. Based in London, he leads Sales, Business Development, Client Engagement, Alliances, and Industry Solutions functions for SunTec globally. Prior to joining SunTec, he served as Vice President & Regional Head for Europe, Americas and Australia, New Zealand as well as Head of Global Alliances for the banking product business of Infosys Limited, a $12 BN global firm. Over the last 26+ years, Amit has handled all the markets in advanced and emerging economies – Europe, Americas including LATAM, Asia, Australia, New Zealand, Middle East and Africa interacting with global and local banks alike. He is a keen business strategist and regularly comments on a range of banking and technology related issues. He has authored several articles and speaks regularly on contemporary topics like trends in banking technology, customer experience management, digital banking, channels, and core banking transformations, to name a few. Amit has a bachelor’s degree in Electronics Engineering and an MBA in Marketing. With his avid interest in customer engagement, Amit can also get extremely competitive on the court as he enjoys playing racket and ball sports including squash, tennis, badminton, cricket, and table tennis. He also finds cooking very therapeutic and spends his Saturday and Sunday evenings cooking a meal for the family. In his free time, Amit enjoys reading non-fiction books, especially corporate histories, and autobiographies. Amit is married with a son and draws strength from his super supportive wife, who infuses energy and positivity into his life.'
    },
    {
        id:2,
        image:'/images/Images-resizing-1-1-300x300.jpg',
        name:'SUDHEER PADIYAR',
        designation:'Senior Vice President, Sales – EMEA',
        content:'Sudheer Padiyar is a seasoned and dynamic sales and marketing professional with over 25 years of experience in the Financial Services and Global Banking Technology Industry. He has successfully led sales and marketing functions across the Americas and Europe for the banking technology solutions from Infosys. During his remarkable career, he has worked closely with CXOs and business leaders of retail and universal banks across Western Europe in defining their transformation road map around Core Banking and Digital. His core competencies include driving customer relationships, business development, interpersonal skills, industry, and product expertise, developing value proposition and solution-based sales techniques to drive the right solutions to address client needs. He has also got an unconventional thinking ability in identifying the problem and implementing innovative solutions. He has led many corporate initiatives such as product licensing and implemented the product licensing policy for leading banking solutions from Infosys.'
    },
    {
        id:3,
        image:'/images/ROHIT-scaled-e1646820810882-1-251x300.jpg',
        name:'ROHIT KAPOOR',
        designation:'General Manager – Sales',
        content:'Rohit Kapoor manages sales at SunTec for the Middle East region. He comes with over 18 years of experience in the software industry and 12+ years in the banking and financial services space. He has extensively engaged with leading banks in the Middle East region to support them in their digital transformation journeys. Over the years, he has acquired rich knowledge in areas such as product and pricing innovation, personalization of customer experience and indirect taxation.'
    },
    
 
];
export default meetourteam