const meetourleaders=[
    {
        id:1,
        image:'/images/Nanda-Kumar-02.png',
        name:'Nanda Kumar',
        designation:'Founder & CEO of SunTec Business Solutions',
        content:'NK is a technology pioneer who, in 1991, built one of India’s first enterprise software product companies. Given his background in Physics, NK was fascinated by the idea of creating something that solves a fundamental human problem, and thereby adds value. He applied this very philosophy to translate intellectual value into a business opportunity, and thus, was born SunTec. NK is recognized for building the first automated billing solution for India’s national telecom provider, which was deployed across the country. He subsequently went on to build Xelerate, SunTec’s flagship platform, that is currently used by more than 130 clients across over 45 countries to provide an enriched customer experience. With nearly three and a half decades of experience as a technology and business evangelist across industries (telecom, banking, financial services, digital communications, retail, travel & logistics), NK has helped shape the wave of customer-centric software platforms and solutions for pricing, billing, and product management, particularly in transaction intensive verticals. Under his leadership, SunTec has won several global awards, including the Celent Model Bank Award, Red Herring Global 100, Deloitte Technology Fast India – 50 and Deloitte Technology Fast Asia-Pacific – 500. An entrepreneur at heart, he has successfully mentored and invested in several technology startups. He also holds several technology patents and has pioneered and patented the concept of real-time value-chain management in digital business eco-systems. He also has a patent for developing software using the product-application-solution framework. His third patent is for building system and method for collaborative designing, development, deployment, execution, monitoring and maintenance of enterprise applications. His patents focus not just on the technological aspect, but also outline the business model designs for clients who can leverage these patents through SunTec’s products. As an author and speaker, NK is known for his views on how organizations can accelerate their digital transformation journey without replacing legacy systems – also referred to as ‘Hollowing out the Core’. He also regularly speaks at various thought leadership forums, including SIBOS, European Banking Forum, 3G Mobile Forum, Indian Banking Summit, Gartner Summit, Association for Financial Professionals, and other leading financial conferences across the world. NK holds leadership positions in several industry forums. He has served as the Chairman of G-Tech, the industry body of IT/ITeS companies in Kerala and also as the head of CII (the industrial forum in India), Trivandrum Zone and continues to be its member. He is also a member of the product council of NASSCOM, the trade association of Indian IT companies. NK holds a master’s degree in Physics and Management and has completed his executive education from London School of Business and Wharton School of Business.'
    },
    {
        id:2,
        image:'/images/Amit-new-300x300.png',
        name:'AMIT DUA',
        designation:'President',
        content:'Amit Dua is President, SunTec Business Solutions. Based in London, he leads Sales, Business Development, Client Engagement, Alliances, and Industry Solutions functions for SunTec globally. Prior to joining SunTec, he served as Vice President & Regional Head for Europe, Americas and Australia, New Zealand as well as Head of Global Alliances for the banking product business of Infosys Limited, a $12 BN global firm. Over the last 26+ years, Amit has handled all the markets in advanced and emerging economies – Europe, Americas including LATAM, Asia, Australia, New Zealand, Middle East and Africa interacting with global and local banks alike. He is a keen business strategist and regularly comments on a range of banking and technology related issues. He has authored several articles and speaks regularly on contemporary topics like trends in banking technology, customer experience management, digital banking, channels, and core banking transformations, to name a few. Amit has a bachelor’s degree in Electronics Engineering and an MBA in Marketing. With his avid interest in customer engagement, Amit can also get extremely competitive on the court as he enjoys playing racket and ball sports including squash, tennis, badminton, cricket, and table tennis. He also finds cooking very therapeutic and spends his Saturday and Sunday evenings cooking a meal for the family. In his free time, Amit enjoys reading non-fiction books, especially corporate histories, and autobiographies. Amit is married with a son and draws strength from his super supportive wife, who infuses energy and positivity into his life.'
    },
    {
        id:3,
        image:'/images/SC-300x300.png',
        name:'SATHISH CHANDRAN',
        designation:'President and Global Head – Demand Fulfillment Group',
        content:'Sathish heads the Demand Fulfilment Group at SunTec comprising Product Engineering, Delivery, Support, Product & Delivery Assurance and CoE teams. With more than 25 years of experience in the software industry and nearly 15 years in revenue management and customer experience, he ensures delivery of our solutions with the highest quality, in the shortest time possible. He manages a proactive support organization which is aligned with our clients’ needs.'
    },
    {
        id:4,
        image:'/images/Imageresize-11-1-300x300.jpg',
        name:'MICHAEL YESUDAS',
        designation:'Chief Technology Officer',
        content:'Michael [Mike] Yesudas is the Chief Technology Officer at SunTec and heads the technology and engineering functions, including platform engineering, product engineering, and release engineering. He has nearly three decades of experience in systems, software and AI solutions and has worked with Fortune 500 clients across verticals – telecom, retail, financial services, manufacturing, and software, to name a few. Prior to this, he has played several significant technology leadership roles across organizations, including IBM, Sterling Commerce, GE, and HP and has handled key projects across EMEA, APAC and America. In his previous role in IBM, he was an IBM Distinguished Engineer and the CTO of IBM Sterling and AI Applications Expert Labs. He completed his BTech at IIT Kharagpur and has an MS in Engineering from the University of Houston and MS in Computer Science from Monash University. He has several U.S. and international patents and has been a CISSP Certified Security Expert for 15 years.'
    },

    {
        id:5,
        image:'/images/MicrosoftTeams-image-55-300x300.png',
        name:'VENKATESH SG',
        designation:'Senior Vice President & Head of Customer Success Group',
        content:'With over 29 years of experience, Venkatesh has spent over 17 years planning, executing, and managing IT-Lead Banking Business Transformation Programs. Venkatesh has held multiple leadership positions during his career. As the Chief Customer Officer at Clari5, a Fintech in the enterprise fraud management and Anti-Money Laundering space, he was responsible for customer engagements and building SI and product partner channels. Prior to this, he was the Senior Vice President – BFSI, responsible for BFSI Line-of-Business at ITC Infotech and the Delivery Head of Finacle responsible for all Finacle-based core banking transformations across Europe, Americas and South-East Asia. He has also worked with leading MNCs such as IBM, Intel and Sonata Software.'
    },

    {
        id:6,
        image:'/images/Images-resizing-1-1-300x300.jpg',
        name:'SUDHEER PADIYAR',
        designation:'Senior Vice President, Sales – EMEA',
        content:'Sudheer Padiyar is a seasoned and dynamic sales and marketing professional with over 25 years of experience in the Financial Services and Global Banking Technology Industry. He has successfully led sales and marketing functions across the Americas and Europe for the banking technology solutions from Infosys. During his remarkable career, he has worked closely with CXOs and business leaders of retail and universal banks across Western Europe in defining their transformation road map around Core Banking and Digital. His core competencies include driving customer relationships, business development, interpersonal skills, industry, and product expertise, developing value proposition and solution-based sales techniques to drive the right solutions to address client needs. He has also got an unconventional thinking ability in identifying the problem and implementing innovative solutions. He has led many corporate initiatives such as product licensing and implemented the product licensing policy for leading banking solutions from Infosys.'
    },

    {
        id:7,
        image:'/images/Nanda-Kumar-Sreedharan-1.jpg',
        name:'NANDA KUMAR SREEDHARAN',
        designation:'Senior Vice President, Sales – Americas',
        content:'Nanda is responsible for new business development and engagement management across the American market. He has over two decades of experience working across industries and expertise in selling pricing, billing and revenue management software.'
    },

    {
        id:8,
        image:'/images/Image-resisize-2-300x300.jpg',
        name:'ARUN KINI',
        designation:'Vice President, Sales – APAC',
        content:'Based in Singapore, Arun Kini is the VP & Regional Head of APAC for the Client Facing Group at SunTec Business Solutions. With over 25 years of experience in the Financial Services & Information Technology industry, Arun has strong domain expertise in Payments, Transaction Banking, Open Banking & Revenue Management. Prior to joining SunTec, he held various leadership roles at Finastra across different parts of the organization – Product, Sales & Account Management, Pre-Sales & Consulting, leading to extensive interactions with C-level executives across the banking industry.'
    },
];
export default meetourleaders